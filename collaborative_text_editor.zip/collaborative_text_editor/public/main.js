"use strict";

let socket = require("socket.io");
let text = {
    text: ''
};



function setup(quill, delta) {
    quill.setContents(delta);
}
