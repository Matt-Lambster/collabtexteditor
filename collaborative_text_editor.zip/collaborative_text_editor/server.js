"use strict";

let socket = require('socket.io');
let express = require('express');
let app = express();
let server = app.listen(process.env.PORT || 8080);
let io = socket(server);


app.use(express.static('public'));

console.log('Server is now listening on port 8080.');

io.sockets.on('connection', connection);

let text = {
  text: ''
};

global["quill"].setText('hi');

function connection(socket) {
    console.log('A new user with id ' + socket.id + " has entered.");

    socket.emit('newUser', text);

    socket.on('new-content', handleTextSent);

    function handleTextSent(data) {
        text.text = data;
        io.sockets.emit('text', data);
    }
}
